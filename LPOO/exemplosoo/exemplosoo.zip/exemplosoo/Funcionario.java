/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosoo;

/**
 *
 * @author rafae
 */
public class Funcionario {
    private String nome;
    private String endereco;
    private String cpf;
    private int numMatricula;
    private double salario;
    private boolean genero;
    
    public Funcionario(String nome, String endereco, String cpf, int numMatricula, double salario, boolean genero){
        if(nome.length()>2)
            this.nome=nome;
        else
            throw new RuntimeException("Nome possui menos do que 3 caracteres");
        this.endereco=endereco;
        this.cpf=cpf;
        this.numMatricula=numMatricula;
        this.salario=salario;
        this.genero=genero;
    }

    public String getNome(){
        if(genero){
            return "Sr. "+this.nome;
        }else{
            return "Sra. "+this.nome;
        }
    }
    
    public void setNome(String nome){
        if(nome.length()>2)
            this.nome=nome;
        else
            throw new RuntimeException("Nome possui menos do que 3 caracteres");
    }
    
    public void setGenero(boolean genero){
        this.genero=genero;
    }
    
    public void dirigirCarro(Carro c){
        c.acelerar(60);
    }
    
    
}
