/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosoo;

/**
 *
 * @author rafae
 */
public class ExemplosOO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Funcionario f = new Funcionario("Rafael","",null,89,3000,true);
        
        //System.out.println(f.getNome());
        
        Carro c = new Carro(20);

        Carro c2 = new Carro(60);

        double vel = Carro.calculaDiferencaVelocidade(c, c2);
        
        double dif =c.calculaDiferencaVelocidade(c2);
        f.dirigirCarro(c2);
        
        System.out.println(vel);
        System.out.println(Carro.contaCarros);
    }
    
}
