/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplosoo;

/**
 *
 * @author rafae
 */
public class Carro {
    public static int contaCarros=0;
    private double velocidade=10;
    
    public Carro(double velocidade){
        this.velocidade=velocidade;
        contaCarros++;
    }
    
    public Carro(){
        contaCarros++;
    }
    
    public void acelerar(double diferenca){
        if(diferenca+this.velocidade<=200)
            this.velocidade+=diferenca;
        else
            throw new RuntimeException("Velocidade excedida");
    }
    
    public double getVelocidade(){
        return this.velocidade;
    }
    
    public double calculaDiferencaVelocidade(double velocidade){
        return Math.abs(this.velocidade-velocidade);
    }
    
    public double calculaDiferencaVelocidade(Carro c){
        return Math.abs(this.velocidade-c.getVelocidade());
    }
    
    public static double calculaDiferencaVelocidade(Carro c1, Carro c2){
        return Math.abs(c1.getVelocidade()-c2.getVelocidade());
    }
    
    
    
}
